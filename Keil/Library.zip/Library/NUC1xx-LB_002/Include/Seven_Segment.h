#ifndef __Seven_Segment_H__
#define __Seven_Segment_H__

extern void OpenSevenSegment(void);
extern void ShowSevenSegment(uint8_t no, uint8_t number);
extern void CloseSevenSegment(void);
#endif
