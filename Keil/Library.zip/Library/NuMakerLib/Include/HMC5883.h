#define HMC5883_I2C_SLA          0xD0
#define HMC5883_I2C_PORT         I2C1

extern void init_HMC5883(void);

